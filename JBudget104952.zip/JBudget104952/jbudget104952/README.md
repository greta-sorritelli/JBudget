<h1>JBudget</h1>
<h2> Author: Greta Sorritelli - 104952 </h2>
Progetto per la realizzazione di un'applicazione che gestisce le finanze tramite conti e transazioni.


Realizzato per il corso di 
<a href="http://didattica.cs.unicam.it/doku.php?id=didattica:triennale:pa:ay_1920:main"> Programmazione Avanzata</a>,
del <a href="https://www.cs.unicam.it/">Corso di Laurea in Informatica</a> di <a href="http://www.unicam.it/">Unicam</a>.
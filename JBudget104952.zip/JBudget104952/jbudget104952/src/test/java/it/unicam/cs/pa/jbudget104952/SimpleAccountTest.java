package it.unicam.cs.pa.jbudget104952;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.function.Predicate;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import org.junit.jupiter.api.Test;

class SimpleAccountTest {

    @Test
    void testSimpleAccount() {
        assertThrows(NullPointerException.class, () -> new SimpleAccount(0, null, null, null, 0));
        assertThrows(NullPointerException.class, () -> new SimpleAccount(15985, null, null, null, 0));
        assertThrows(NullPointerException.class, () -> new SimpleAccount(0, AccountType.LIABILITIES, null, null, 0));
        assertThrows(NullPointerException.class, () -> new SimpleAccount(0, AccountType.ASSETS, null, null, 0));
        assertThrows(NullPointerException.class, () -> new SimpleAccount(0, null, "name", null, 0));
        SimpleLedger l = new SimpleLedger();
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
        assertEquals(10, b.getID());
        assertEquals(10, b.getBalance());
        GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21);
        SimpleTransaction t = new SimpleTransaction(1789, d);
        SimpleMovement m = new SimpleMovement(195, "movimento1", MovementsType.CREDITS, b, 10);
        t.addMovement(m);
        l.addTransaction(t);
        assertEquals(20.0, b.getBalance());
        assertTrue(b.getMovements().contains(m));
        assertTrue(t.getMovements().contains(m));
    }

    @Test
    void testAddAmount() {
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
        b.addAmount(20);
        assertEquals(30, b.getBalance());
        b.addAmount(25);
        assertEquals(55, b.getBalance());
        b.addAmount(15.23);
        assertEquals(70.23, b.getBalance());
        b.addAmount(0.77);
        assertEquals(71, b.getBalance());
    }

    @Test
    void testSubtractAmount() {
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
        assertThrows(IllegalArgumentException.class, () -> b.subtractAmount(20));
        b.setBalance(40);
        b.subtractAmount(30);
        assertEquals(10, b.getBalance());
        b.subtractAmount(0.91);
        assertEquals(9.09, b.getBalance());
    }

    @Test
    void getMovements() {
        SimpleLedger l = new SimpleLedger();
        SimpleTag simpleTag = new SimpleTag(16, "casa", "bolletta");
        SimpleTag simpleTag1 = new SimpleTag(17, "palestra", "abbonamento");
        SimpleAccount a = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
        GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21);
        SimpleTransaction t = new SimpleTransaction(1789, d);
        SimpleMovement m = new SimpleMovement(195, "movimento1", MovementsType.CREDITS, a, 10);
        t.addMovement(m);
        m.addTag(simpleTag);
        SimpleMovement n = new SimpleMovement(196, "movimento2", MovementsType.CREDITS, a, 10);
        t.addMovement(n);
        n.addTag(simpleTag1);
        SimpleMovement o = new SimpleMovement(197, "movimento3", MovementsType.CREDITS, a, 10);
        t.addMovement(o);
        o.addTag(simpleTag);
        l.addTransaction(t);
        assertTrue(m.getTag().contains(simpleTag));
        Predicate<Movement> p = movement -> movement.getTag().contains(simpleTag);
        assertEquals(2, a.getMovements(p).size());
        assertTrue(a.getMovements(p).contains(m));
        assertTrue(a.getMovements(p).contains(o));
        assertFalse(a.getMovements(p).contains(n));
        Predicate<Movement> r = movements -> movements.getTag().contains(simpleTag1);
        assertEquals(1, a.getMovements(r).size());
        assertTrue(a.getMovements(r).contains(n));
        Predicate<Movement> s = movements -> movements.getID() == 195;
        assertEquals(1, a.getMovements(s).size());
        assertTrue(a.getMovements(s).contains(m));
        Predicate<Movement> b = movements -> movements.getType().equals(MovementsType.CREDITS);
        assertEquals(3, a.getMovements(b).size());
        Predicate<Movement> c = movements -> movements.getType().equals(MovementsType.DEBIT);
        assertEquals(0, a.getMovements(c).size());
    }
}

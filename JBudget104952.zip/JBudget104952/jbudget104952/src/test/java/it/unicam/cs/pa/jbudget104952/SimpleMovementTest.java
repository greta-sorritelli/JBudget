package it.unicam.cs.pa.jbudget104952;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import org.junit.jupiter.api.Test;

class SimpleMovementTest {


	@Test
	void testAddTag() {
		SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
		GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21);
		SimpleTransaction t = new SimpleTransaction(1789, d);
		SimpleMovement m = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
		SimpleTag simpleTag = new SimpleTag(26, "casa", "bollette");
		m.addTag(simpleTag);
		assertTrue(m.getTag().contains(simpleTag));
		assertEquals(1, m.getTag().size());
		SimpleTag tagg = new SimpleTag(0, "null", null);
		m.addTag(tagg);
		assertTrue(m.getTag().contains(tagg));
		m.addTag(tagg);
		assertEquals(2, m.getTag().size());
	}

	@Test
	void testRemoveTag() {
		SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
		GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21);
		SimpleTransaction t = new SimpleTransaction(1789, d);
		SimpleMovement m = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
		SimpleTag simpleTag = new SimpleTag(26, "casa", "bollette");
		m.addTag(simpleTag);
		assertTrue(m.getTag().contains(simpleTag));
		SimpleTag tagg = new SimpleTag(0, "null", null);
		m.addTag(tagg);
		assertTrue(m.getTag().contains(tagg));
		m.removeTag(tagg);
		assertFalse(m.getTag().contains(tagg));
		assertEquals(1, m.getTag().size());
		m.removeTag(simpleTag);
		assertFalse(m.getTag().contains(simpleTag));
		assertEquals(0, m.getTag().size());
	}

}

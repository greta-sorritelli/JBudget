package it.unicam.cs.pa.jbudget104952;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.function.Predicate;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import org.junit.jupiter.api.Test;

class SimpleLedgerTest {

	@Test
	void testAddAccount() {
		SimpleLedger ledger = new SimpleLedger();
		ledger.addAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
		SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
		assertTrue(ledger.getAccount().contains(b));
		assertEquals(1, ledger.getAccount().size());
		assertThrows(NullPointerException.class, () -> ledger.addAccount(20, null, "nuovo", "carta", 10));
		assertThrows(NullPointerException.class, () -> ledger.addAccount(20, AccountType.ASSETS, null, "carta", 10));
		assertThrows(IllegalArgumentException.class,
				() -> ledger.addAccount(20, AccountType.ASSETS, "carta", "carta", -3));
		assertThrows(IllegalArgumentException.class,
				() -> ledger.addAccount(-20, AccountType.ASSETS, "carta", "carta", 3));
		ledger.addAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
		assertEquals(1, ledger.getAccount().size());
		ledger.addAccount(70, AccountType.ASSETS, "nuovo", "carta", 10);
		assertEquals(2, ledger.getAccount().size());
	}

	@Test
	void testRemoveAccount() {
		SimpleLedger ledger = new SimpleLedger();
		final SimpleAccount d = new SimpleAccount(11, AccountType.ASSETS, "nuovo", "carta", 10);
		assertThrows(IllegalArgumentException.class, () -> ledger.removeAccount(d));
		ledger.addAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
		SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
		assertTrue(ledger.getAccount().contains(b));
		ledger.removeAccount(b);
		assertEquals(0, ledger.getAccount().size());
		assertFalse(ledger.getAccount().contains(b));
		assertThrows(IllegalArgumentException.class, () -> ledger.removeAccount(b));
	}

	@Test
	void testAddTransaction() {
		SimpleLedger ledger = new SimpleLedger();
		GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21, 17, 30);
		SimpleTransaction t = new SimpleTransaction(1789, d);
		ledger.addTransaction(t);
		assertTrue(ledger.getTransactions().contains(t));
		assertThrows(NullPointerException.class, () -> ledger.addTransaction(null));
		SimpleTransaction z = new SimpleTransaction(1789, d);
		ledger.addTransaction(z);
		assertEquals(1, ledger.getTransactions().size());
	}

	@Test
	void testRemoveTransaction() {
		SimpleLedger ledger = new SimpleLedger();
		GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21, 17, 30);
		SimpleTransaction t = new SimpleTransaction(1789, d);
		assertThrows(IllegalStateException.class, () -> ledger.removeTransaction(null));
		assertThrows(IllegalStateException.class, () -> ledger.removeTransaction(t));
		SimpleAccount b = ledger.addAccount(10, AccountType.ASSETS, "nuovo", "carta", 100);
		SimpleAccount a = ledger.addAccount(11, AccountType.LIABILITIES, "nuovo", "carta", 200);
		assertTrue(ledger.getAccount().contains(b));
		assertTrue(ledger.getAccount().contains(a));
		SimpleMovement m = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
		SimpleMovement n = new SimpleMovement(52, "nuova", MovementsType.CREDITS, a, 10);
		t.addMovement(m);
		t.addMovement(n);
		ledger.addTransaction(t);
		assertTrue(ledger.getTransactions().contains(t));
		assertTrue(ledger.getAccount().get(0).getMovements().contains(m));
		assertTrue(ledger.getAccount().get(1).getMovements().contains(n));
		assertTrue(t.getMovements().contains(m));
		assertTrue(t.getMovements().contains(n));
		assertTrue(a.getMovements().contains(n));
		assertTrue(b.getMovements().contains(m));
		ledger.removeTransaction(t);
		assertTrue(ledger.getAccount().contains(a));
		assertTrue(ledger.getAccount().contains(b));
		assertFalse(ledger.getAccount().get(0).getMovements().contains(m));
		assertFalse(ledger.getAccount().get(1).getMovements().contains(n));
		assertFalse(ledger.getTransactions().contains(t));
		assertFalse(b.getMovements().contains(m));
		assertFalse(a.getMovements().contains(n));
	}

	@Test
	void testAddTag() {
		SimpleLedger ledger = new SimpleLedger();
		SimpleTag simpleTag = new SimpleTag(26, "casa", "bollette");
		SimpleTag simpleTag1 = new SimpleTag(24, "casa", "bollette");
		assertThrows(NullPointerException.class, () -> ledger.addTag(0, null, "des"));
		assertThrows(IllegalArgumentException.class, () -> ledger.addTag(-1, "nome", "des"));
		ledger.addTag(26, "casa", "bollette");
		assertTrue(ledger.getTags().contains(simpleTag));
		assertEquals(1, ledger.getTags().size());
		ledger.addTag(26, "casa", "bollette");
		assertEquals(1, ledger.getTags().size());
		ledger.addTag(24, "casa", "bollette");
		assertTrue(ledger.getTags().contains(simpleTag1));
		assertEquals(2, ledger.getTags().size());
	}

	@Test
	void testRemoveTag() {
		SimpleLedger ledger = new SimpleLedger();
		SimpleTag simpleTag = new SimpleTag(26, "casa", "bollette");
		SimpleTag simpleTag1 = new SimpleTag(24, "casa", "bollette");
		assertThrows(IllegalStateException.class, () -> ledger.removeTag(null));
		assertThrows(IllegalStateException.class, () -> ledger.removeTag(simpleTag));
		assertThrows(IllegalStateException.class, () -> ledger.removeTag(simpleTag1));
		ledger.addTag(26, "casa", "bollette");
		ledger.addTag(24, "casa", "bollette");
		assertEquals(2, ledger.getTags().size());
		ledger.removeTag(simpleTag);
		assertFalse(ledger.getTags().contains(simpleTag));
		assertEquals(1, ledger.getTags().size());
		ledger.removeTag(simpleTag1);
		assertFalse(ledger.getTags().contains(simpleTag));
		assertEquals(0, ledger.getTags().size());
	}

	@Test
	void testGetTransactions() {
		SimpleLedger ledger = new SimpleLedger();
		SimpleTag simpleTag = new SimpleTag(26, "casa", "bollette");
		SimpleTag simpleTag1 = new SimpleTag(24, "casa", "bollette");
		GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21, 17, 30);
		SimpleTransaction t = new SimpleTransaction(1789, d);
		SimpleTransaction u = new SimpleTransaction(1790, d);
		SimpleTransaction v = new SimpleTransaction(1791, d);
		ledger.addTransaction(t);
		ledger.addTransaction(u);
		ledger.addTransaction(v);
		t.addTag(simpleTag1);
		u.addTag(simpleTag1);
		v.addTag(simpleTag);
		Predicate<Transaction> p = transaction -> transaction.getTags().contains(simpleTag);
		assertEquals(1, ledger.getTransactions(p).size());
		Predicate<Transaction> r = transaction -> transaction.getTags().contains(simpleTag1);
		assertEquals(2, ledger.getTransactions(r).size());
		Predicate<Transaction> s = transaction -> transaction.getDate().equals(d);
		assertEquals(3, ledger.getTransactions(s).size());
		Predicate<Transaction> z = transaction -> transaction.getID() == 1789;
		assertEquals(1, ledger.getTransactions(z).size());
		assertTrue(ledger.getTransactions(z).contains(t));
	}

}

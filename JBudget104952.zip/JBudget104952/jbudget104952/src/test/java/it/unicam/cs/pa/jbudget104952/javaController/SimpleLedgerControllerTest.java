package it.unicam.cs.pa.jbudget104952.javaController;

import it.unicam.cs.pa.jbudget104952.javaModel.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class SimpleLedgerControllerTest {

    @Test
    void control() {
        SimpleLedgerController c = new SimpleLedgerController();
        SimpleAccount a = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 10);
        SimpleAccount b = new SimpleAccount(11, AccountType.LIABILITIES, "nuovo", "carta", 10);
        SimpleMovement m = new SimpleMovement(195, "movimento1", MovementsType.CREDITS, a, 11);
        SimpleMovement n = new SimpleMovement(196, "movimento1", MovementsType.DEBIT, a, 11);
        SimpleMovement o = new SimpleMovement(195, "movimento1", MovementsType.CREDITS, b, 11);
        SimpleMovement p = new SimpleMovement(196, "movimento1", MovementsType.DEBIT, b, 11);
        assertTrue(c.control(m));
        assertTrue(c.control(p));
        assertFalse(c.control(n));
        assertFalse(c.control(o));
    }
}
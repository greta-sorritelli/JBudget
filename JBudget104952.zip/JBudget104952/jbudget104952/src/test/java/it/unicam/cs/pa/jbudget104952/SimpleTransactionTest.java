package it.unicam.cs.pa.jbudget104952;

import static org.junit.jupiter.api.Assertions.*;
import java.util.Calendar;
import java.util.GregorianCalendar;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import org.junit.jupiter.api.Test;

class SimpleTransactionTest {

    @Test
    void testGetTotalAmount() {
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 100);
        SimpleAccount c = new SimpleAccount(11, AccountType.LIABILITIES, "nuovo", "carta", 100);
        SimpleAccount d = new SimpleAccount(12, AccountType.ASSETS, "nuovo", "carta", 100);
        GregorianCalendar e = new GregorianCalendar(2020, Calendar.JANUARY, 21, 17, 30);
        SimpleTransaction t = new SimpleTransaction(1789, e);
        SimpleMovement m = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
        SimpleMovement n = new SimpleMovement(54, "nuova", MovementsType.DEBIT, c, 1);
        SimpleMovement o = new SimpleMovement(55, "nuova", MovementsType.DEBIT, d, 10.50);
        t.addMovement(m);
        t.addMovement(n);
        t.addMovement(o);
        assertEquals(t.getTotalAmount(), -1.50);
    }

    @Test
    void testAddTag() {
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 100);
        GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21, 17, 30);
        SimpleTransaction t = new SimpleTransaction(1789, d);
        SimpleTag simpleTag = new SimpleTag(26, "casa", "bollette");
        SimpleMovement m = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
        t.addMovement(m);
        t.addTag(simpleTag);
        assertTrue(t.getTags().contains(simpleTag));
        assertEquals(1, t.getTags().size());
        assertTrue(m.getTag().contains(simpleTag));
        SimpleTag tagg = new SimpleTag(0, "null", null);
        t.addTag(tagg);
        assertTrue(t.getTags().contains(tagg));
        assertTrue(m.getTag().contains(tagg));
        t.addTag(tagg);
        assertEquals(2, t.getTags().size());
        assertEquals(2, m.getTag().size());
    }

    @Test
    void testRemoveTag() {
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 100);
        GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21, 17, 30);
        SimpleTransaction t = new SimpleTransaction(1789, d);
        SimpleMovement m = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
        t.addMovement(m);
        SimpleTag simpleTag = new SimpleTag(26, "casa", "bollette");
        t.addTag(simpleTag);
        SimpleTag tagg = new SimpleTag(0, "null", null);
        t.addTag(tagg);
        SimpleTag simpleTag1 = new SimpleTag(27, "casa", "bollette");
        t.addTag(simpleTag1);
        SimpleTag tagg1 = new SimpleTag(8, "null", null);
        t.addTag(tagg1);
        assertEquals(4, t.getTags().size());
        t.removeTag(simpleTag);
        assertEquals(3, t.getTags().size());
        t.removeTag(tagg);
        assertEquals(2, t.getTags().size());
        t.removeTag(simpleTag1);
        t.removeTag(tagg1);
        assertEquals(0, t.getTags().size());
        assertFalse(m.getTag().contains(simpleTag));
        assertFalse(m.getTag().contains(tagg));
        assertFalse(m.getTag().contains(simpleTag1));
        assertFalse(m.getTag().contains(tagg1));
    }

    @Test
    void testAddMovement() {
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 100);
        GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21);
        SimpleTransaction t = new SimpleTransaction(1789, d);
        SimpleMovement m = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
        t.addMovement(m);
        SimpleMovement n = new SimpleMovement(52, "nuova", MovementsType.DEBIT, b, 10);
        t.addMovement(n);
        assertEquals(2, t.getMovements().size());
        assertEquals(2, t.getMovements().size());
        SimpleMovement v = new SimpleMovement(57, "nuova", MovementsType.DEBIT, b, 10);
        t.addMovement(v);
        assertEquals(3, t.getMovements().size());
        SimpleMovement z = new SimpleMovement(59, "nuova", MovementsType.DEBIT, b, 0.01);
        t.addMovement(z);
        assertEquals(4, t.getMovements().size());
    }

    @Test
    void testRemoveMovement() {
        SimpleAccount b = new SimpleAccount(10, AccountType.ASSETS, "nuovo", "carta", 100);
        GregorianCalendar d = new GregorianCalendar(2020, Calendar.JANUARY, 21);
        SimpleTransaction t = new SimpleTransaction(1789, d);
        SimpleMovement z = new SimpleMovement(53, "nuova", MovementsType.CREDITS, b, 10);
        SimpleMovement i = new SimpleMovement(52, "nuova", MovementsType.DEBIT, b, 10);
        t.addMovement(z);
        t.addMovement(i);
        assertEquals(2, t.getMovements().size());
        t.removeMovement(z);
        assertEquals(1, t.getMovements().size());
        SimpleMovement y = new SimpleMovement(57, "nuova", MovementsType.DEBIT, b, 10);
        t.addMovement(y);
        assertEquals(2, t.getMovements().size());
        SimpleMovement e = new SimpleMovement(59, "nuova", MovementsType.DEBIT, b, 0.01);
        t.addMovement(e);
        assertEquals(3, t.getMovements().size());
        t.removeMovement(y);
        assertEquals(2, t.getMovements().size());
        t.removeMovement(e);
        assertEquals(1, t.getMovements().size());
    }

}

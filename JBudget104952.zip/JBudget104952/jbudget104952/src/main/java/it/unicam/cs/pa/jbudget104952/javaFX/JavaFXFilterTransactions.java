package it.unicam.cs.pa.jbudget104952.javaFX;

import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.function.Predicate;

public class JavaFXFilterTransactions implements JavaFXFilter{

    private final SimpleLedgerController controller;

    public JavaFXFilterTransactions(SimpleLedgerController controller) {
        this.controller = controller;
    }

    @FXML
    TableView<Transaction> transactionTableView = new TableView<>();
    @FXML
    TableColumn<Transaction, Integer> transactionID = new TableColumn<>();
    @FXML
    TableColumn<Transaction, Date> transactionDate = new TableColumn<>();
    @FXML
    TableColumn<Transaction, Double> transactionAmount = new TableColumn<>();
    @FXML
    TableColumn<Transaction, List<Tag>> transactionTags = new TableColumn<>();


    @FXML
    public void initialize() {
        fillListTags();
        transactionRefresh();
    }

    /**
     * Aggiorna i dati della tabella relativa alle Transaction.
     */
    @FXML
    public void transactionRefresh() {
        setTransactionCellValueFactory();
        transactionTableView.getItems().clear();
        for (Transaction transaction : controller.getTransactions())
            transactionTableView.getItems().add(transaction);
    }

    /**
     * Riempie la tabella con i dati delle Transaction.
     */
    private void setTransactionCellValueFactory() {
        transactionID.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getID()));
        transactionDate.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getDate().getTime()));
        transactionTags.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getTags()));
        transactionAmount.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getTotalAmount()));
    }


    @FXML
    TextField idFilter;
    @FXML
    ChoiceBox<String> amountFilter;
    final ObservableList<String> types = FXCollections.observableArrayList("Negative", "Positive");
    @FXML
    ChoiceBox<Tag> tagFilter = new ChoiceBox<>();
    final ObservableList<Tag> tags = FXCollections.observableArrayList();
    @FXML
    DatePicker dateFilter;

    private void fillListTags() {
        for(Tag t : controller.getTags()) {
            if(!tags.contains(t))
                tags.add(t);
        }
    }

    @FXML
    public void initAmount() {
        amountFilter.setItems(types);
    }


    @FXML
    public void initTag() {
        tagFilter.setItems(tags);
    }

    /**
     * Filtra le Transaction in base ai vari predicati presenti
     */
    @FXML
    @Override
    public void filter() {
        transactionTableView.getItems().clear();
        List<Predicate<Transaction>> finalPredicate = new ArrayList<>();
        controlID(finalPredicate);
        controlDate(finalPredicate);
        controlAmount(finalPredicate);
        controlTag(finalPredicate);
        reduce(finalPredicate);
    }

    /**
     * Crea un predicato per l'ID se è inserito come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlID(List<Predicate<Transaction>> finalPredicate) {
        if (!idFilter.getText().equals("")) {
            Predicate<Transaction> idPredicate;
            try {
                if (Integer.parseInt(idFilter.getText()) > 0) {
                    idPredicate = (transaction -> transaction.getID() == Integer.parseInt(idFilter.getText()));
                    finalPredicate.add(idPredicate);
                }
            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Invalid ID.");
                alert.showAndWait();
                e.printStackTrace();
            }
        }
    }

    /**
     * Crea un predicato per la data se è inserita come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlDate(List<Predicate<Transaction>> finalPredicate) {
        LocalDate date;
        ZonedDateTime zonedDateTime;
        if (dateFilter.getValue() != null) {
            date = dateFilter.getValue();
            zonedDateTime = date.atStartOfDay(ZoneId.systemDefault());
            Predicate<Transaction> datePredicate;
            datePredicate = (transaction -> transaction.getDate().equals(GregorianCalendar.from(zonedDateTime)));
            finalPredicate.add(datePredicate);
        }
    }

    /**
     * Crea un predicato per il total amount se è inserito come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlAmount(List<Predicate<Transaction>> finalPredicate) {
        if (amountFilter.getValue() != null) {
            Predicate<Transaction> amountPredicate;
            if (amountFilter.getValue().equals("Positive")) {
                amountPredicate = (transaction -> transaction.getTotalAmount() >= 0);
            } else {
                amountPredicate = (transaction -> transaction.getTotalAmount() < 0);
            }
            finalPredicate.add(amountPredicate);
        }
    }

    /**
     * Crea un predicato per il tag se è inserito come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlTag(List<Predicate<Transaction>> finalPredicate) {
        if (tagFilter.getValue() != null) {
            Predicate<Transaction> tagPredicate;
            tagPredicate = (transaction -> transaction.getTags().contains(tagFilter.getValue()));
            finalPredicate.add(tagPredicate);
        }
    }

    /**
     * Riduce la lista di predicati ad un solo predicato.
     * I predicati sono concatenati con gli and logici, tutti i predicati devono essere soddisfatti.
     * @param list lista di parametri da ridurre
     */
    public void reduce(List<Predicate<Transaction>> list) {
        Predicate<Transaction> predicate = list.stream()
                .reduce(x -> true, Predicate::and);
        showTransactions(predicate);
    }


    private void showTransactions(Predicate<Transaction> predicate) {
        transactionTableView.getItems().clear();
        for (Transaction transaction : controller.getTransactions(predicate))
            transactionTableView.getItems().add(transaction);
    }

    /**
     * Resetta i campi dei parametri da inserire e ritorna la lista iniziale di tutte le Transaction
     */
    @FXML
    @Override
    public void reset() {
        idFilter.clear();
        dateFilter.getEditor().clear();
        amountFilter.getSelectionModel().clearSelection();
        tagFilter.getSelectionModel().clearSelection();
        transactionRefresh();
    }

}

package it.unicam.cs.pa.jbudget104952.javaFX;

import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import javafx.beans.property.SimpleObjectProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.stage.DirectoryChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;

/**
 * Classe per le operazioni principali del ledger.
 *
 * @author Greta Sorritelli
 */
public class JavaFXLedgerController {


    private final SimpleLedgerController controller = new SimpleLedgerController();


    @FXML
    TableView<Account> accountsTableView;
    @FXML
    TableColumn<Account, Integer> accountTableID;
    @FXML
    TableColumn<Account, String> accountTableName;
    @FXML
    TableColumn<Account, String> accountTableDescription;
    @FXML
    TableColumn<Account, AccountType> accountTableType;
    @FXML
    TableColumn<Account, Double> accountTableOpeningBalance;
    @FXML
    TableColumn<Account, Double> accountTableBalance;


    /**
     * Aggiorna i dati della tabella relativa agli Account del ledger.
     */
    @FXML
    public void accountRefresh() {
        setAccountCellValueFactory();
        accountsTableView.getItems().clear();
        for (Account account : controller.getAccount())
            accountsTableView.getItems().add(account);
    }

    /**
     * Riempie la tabella con i dati relativi agli Account
     */
    private void setAccountCellValueFactory() {
        accountsTableView.setEditable(true);
        accountsTableView.getSelectionModel().setSelectionMode(
                SelectionMode.MULTIPLE
        );
        accountTableID.setCellValueFactory(account -> new SimpleObjectProperty<>(account.getValue().getID()));
        accountTableName.setCellValueFactory(account -> new SimpleObjectProperty<>(account.getValue().getName()));
        accountTableDescription.setCellValueFactory(account -> new SimpleObjectProperty<>(account.getValue().getDescription()));
        accountTableType.setCellValueFactory(account -> new SimpleObjectProperty<>(account.getValue().getType()));
        accountTableOpeningBalance.setCellValueFactory(account -> new SimpleObjectProperty<>(account.getValue().getOpeningBalance()));
        accountTableBalance.setCellValueFactory(account -> new SimpleObjectProperty<>(account.getValue().getBalance()));
    }


    /**
     * Metodo privato per aprire una nuova finestra.
     * @param file file per la nuova finestra
     * @param title titolo
     * @param controller controllore della nuova finestra
     * @throws IOException eccezione per l'apertura della finestra
     */
    private void openNewWindow(String file, String title, Object controller) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource(file));
        fxmlLoader.setController(controller);
        Parent root = fxmlLoader.load();
        Stage stage = new Stage();
        stage.setTitle(title);
        Image ico = new Image("/money.png");
        stage.getIcons().add(ico);
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setScene(new Scene(root));
        stage.resizableProperty().set(false);
        stage.showAndWait();
    }


    /**
     * Aggiunta di un Account al ledger. Apre una nuova finestra.
     */
    @FXML
    public void addAccount() {
        try {
            openNewWindow("/AddAccount.fxml", "Add a new account", new JavaFXAddAccount(controller));
            accountRefresh();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    /**
     * Rimozione di uno o più Account dal ledger.
     */
    @FXML
    public void removeAccount() {
        List<Account> sel = new ArrayList<>(accountsTableView.getSelectionModel().getSelectedItems());
        for (Account acc : sel) {
            if (acc != null)
                controller.removeAccount(acc);
        }
        accountsTableView.getItems().removeAll(sel);
        accountRefresh();
    }

    /**
     * Gestisce il doppio click su un Account per mostrare i movimenti relativi
     */
    @FXML
    public void getMovementsAccount() {
        accountsTableView.setOnMouseClicked(click -> {
            if (click.getClickCount() == 2) {
                Account account = accountsTableView.getSelectionModel().getSelectedItem();
                if (!account.getMovements().isEmpty())
                    filterMovements(account);
            }
        });
    }

    /**
     * Apre la nuova finestra di Movement dell'Account passato come parametro
     * @param account account di cui visualizzare i movimenti
     */
    private void filterMovements(Account account) {
        try {
            JavaFXAccountMovements am = new JavaFXAccountMovements(controller);
            am.setAccount(account);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/AccountMovements.fxml"));
            fxmlLoader.setController(am);
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("Filter Movements");
            Image ico = new Image("/money.png");
            stage.getIcons().add(ico);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.resizableProperty().set(false);
            stage.setOnShowing(e -> am.initialize());
            stage.showAndWait();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }


    @FXML
    TableView<Transaction> transactionsTableView;
    @FXML
    TableColumn<Transaction, Integer> transactionID;
    @FXML
    TableColumn<Transaction, Date> transactionDate;
    @FXML
    TableColumn<Transaction, List<Tag>> tagTransaction;
    @FXML
    TableColumn<Transaction, Double> getTotAmount;


    /**
     * Aggiorna i dati della tabella relativa alle Transaction.
     */
    @FXML
    public void transactionRefresh() {
        setTransactionCellValueFactory();
        transactionsTableView.getItems().clear();
        for (Transaction transaction : controller.getTransactions())
            transactionsTableView.getItems().add(transaction);
    }

    /**
     * Riempie la tabella con i dati relativi alle Transaction.
     */
    private void setTransactionCellValueFactory() {
        transactionsTableView.setEditable(true);
        transactionsTableView.getSelectionModel().setSelectionMode(
                SelectionMode.MULTIPLE
        );
        transactionID.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getID()));
        transactionDate.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getDate().getTime()));
        tagTransaction.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getTags()));
        getTotAmount.setCellValueFactory(transaction -> new SimpleObjectProperty<>(transaction.getValue().getTotalAmount()));
    }

    /**
     * Aggiunta di una Transaction. Apre una nuova finestra.
     */
    @FXML
    public void addTransaction() {
        try {
            openNewWindow("/AddTransaction.fxml", "Add a new transaction", new JavaFXAddTransaction(controller));
            transactionRefresh();
            accountRefresh();
            movementRefresh();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    /**
     * Rimozione di una o più Transaction.
     */
    @FXML
    public void removeTransaction() {
        List<Transaction> sel = new ArrayList<>(transactionsTableView.getSelectionModel().getSelectedItems());
        for (Transaction tr : sel) {
            if (tr != null)
                controller.removeTransaction(tr);
        }
        transactionsTableView.getItems().removeAll(sel);
        transactionRefresh();
        movementRefresh();
        accountRefresh();
    }

    /**
     * Apre una nuova finestra per filtrare le Transaction
     */
    @FXML
    public void filterTransactions() {
        try {
            JavaFXFilterTransactions ft = new JavaFXFilterTransactions(controller);
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/FilterTransactions.fxml"));
            fxmlLoader.setController(ft);
            Parent root = fxmlLoader.load();
            Stage stage = new Stage();
            stage.setTitle("Filter transactions");
            Image ico = new Image("/money.png");
            stage.getIcons().add(ico);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.setScene(new Scene(root));
            stage.resizableProperty().set(false);
            stage.setOnShowing(e -> ft.initialize());
            stage.showAndWait();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    /**
     * Aggiunta di un Tag ad una Transaction. Apre una nuova finestra.
     */
    @FXML
    public void addTagTransaction() {
        try {
            openNewWindow("/AddTagTransaction.fxml", "Add a new tag to a transaction", new JavaFXAddTagTransaction(controller));
            transactionRefresh();
            movementRefresh();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    /**
     * Rimozione di un Tag da una Transaction. Apre una nuova finestra.
     */
    @FXML
    public void removeTagTransaction() {
        try {
            openNewWindow("/RemoveTagTransaction.fxml", "Remove a tag from a transaction", new JavaFXRemoveTagTransaction(controller));
            transactionRefresh();
            movementRefresh();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    @FXML
    TableView<Movement> movementTableView;
    @FXML
    TableColumn<Movement, Integer> movementID;
    @FXML
    TableColumn<Movement, Date> movementDate;
    @FXML
    TableColumn<Movement, MovementsType> movementType;
    @FXML
    TableColumn<Movement, String> movementDescription;
    @FXML
    TableColumn<Movement, String> movementAccount;
    @FXML
    TableColumn<Movement, Integer> movementTransaction;
    @FXML
    TableColumn<Movement, Double> movementAmount;
    @FXML
    TableColumn<Movement, List<Tag>> movementTags;


    /**
     * Aggiorna i dati della tabella relativa ai Movement.
     */
    @FXML
    public void movementRefresh() {
        setMovementCellValueFactory();
        movementTableView.getItems().clear();
        for (Transaction t : controller.getTransactions()) {
            for (Movement movement : t.getMovements())
                movementTableView.getItems().add(movement);
        }

    }

    /**
     * Riempie la tabella con i dati relativi ai Movement.
     */
    private void setMovementCellValueFactory() {
        movementID.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getID()));
        movementDescription.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getDescription()));
        movementType.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getType()));
        movementDate.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getDate().getTime()));
        movementTransaction.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getTransactions().getID()));
        movementAccount.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getAccount().toString()));
        movementAmount.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getAmount()));
        movementTags.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getTag()));
    }

    /**
     * Aggiunta di un Tag ad un Movement. Apre una nuova finestra.
     */
    @FXML
    public void addTagMovement() {
        try {
            openNewWindow("/AddTagToMovement.fxml", "Add tags to the movement", new JavaFXAddTagMovement(controller));
            movementRefresh();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    /**
     * Rimozione di un Tag da un Movement.
     */
    @FXML
    public void removeTagMovement() {
        try {
            openNewWindow("/RemoveTagMovement.fxml", "Remove tags from a movement", new JavaFXRemoveTagMovement(controller));
            movementRefresh();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }


    @FXML
    TableView<Tag> tagsTableView;
    @FXML
    TableColumn<Tag, Integer> tagID;
    @FXML
    TableColumn<Tag, String> tagName;
    @FXML
    TableColumn<Tag, String> tagDescription;

    /**
     * Aggiorna i dati della tabella relativa ai Tag.
     */
    public void tagRefresh() {
        setTagCellValueFactory();
        tagsTableView.getItems().clear();
        for (Tag tag : controller.getTags())
            tagsTableView.getItems().add(tag);
    }

    /**
     * Riempie la tabella con i dati relativi ai Tag.
     */
    private void setTagCellValueFactory() {
        tagsTableView.setEditable(true);
        tagsTableView.getSelectionModel().setSelectionMode(
                SelectionMode.MULTIPLE
        );
        tagID.setCellValueFactory(tag -> new SimpleObjectProperty<>(tag.getValue().getID()));
        tagName.setCellValueFactory(tag -> new SimpleObjectProperty<>(tag.getValue().getName()));
        tagDescription.setCellValueFactory(tag -> new SimpleObjectProperty<>(tag.getValue().getDescription()));
    }

    /**
     * Aggiunta di un Tag. Apre una nuova finestra.
     */
    @FXML
    public void addTag() {
        try {
            openNewWindow("/AddTag.fxml", "Add a new tag", new JavaFXAddTagLedger(controller));
            tagRefresh();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    /**
     * Rimozione di un Tag.
     */
    @FXML
    public void removeTag() {
        List<Tag> sel = new ArrayList<>(tagsTableView.getSelectionModel().getSelectedItems());
        for (Tag tag : sel) {
            if (tag != null)
                controller.removeTag(tag);
        }
        tagsTableView.getItems().removeAll(sel);
        tagRefresh();
        transactionRefresh();
        movementRefresh();
    }


    @FXML
    TextField directoryExportPath;
    @FXML
    TextField directoryImportPath;
    @FXML
    Button export;
    @FXML
    Button imports;


    /**
     * Esporta tutti i dati in diversi file txt.
     */
    @FXML
    public void saveTxt() {
        if(directoryExportPath.getText().equals("")) {
            File directory = new DirectoryChooser().showDialog(export.getScene().getWindow());
            directoryExportPath.setText(directory.getAbsolutePath());
        }
        try {
            if(!Objects.isNull(directoryExportPath))
                controller.saveAsTxt(directoryExportPath.getText());
            Alert alertMessage = new Alert(Alert.AlertType.INFORMATION);
            alertMessage.setContentText("Export successful.");
            alertMessage.showAndWait();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Impossible export.");
            alert.showAndWait();
        }

    }

    /**
     * Importa tutti i dati da diversi file txt.
     */
    @FXML
    public void importTxt() {
        if(directoryImportPath.getText().equals("")) {
            File directory = new DirectoryChooser().showDialog(imports.getScene().getWindow());
            directoryImportPath.setText(directory.getAbsolutePath());
        }
        try {
            if(!Objects.isNull(directoryImportPath))
                controller.importAsTxt(directoryImportPath.getText());
            transactionRefresh();
            tagRefresh();
            movementRefresh();
            accountRefresh();
            Alert alertMessage = new Alert(Alert.AlertType.INFORMATION);
            alertMessage.setContentText("Import successful.");
            alertMessage.showAndWait();
        } catch (IOException | ParseException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Impossible import.");
            alert.showAndWait();
        }

    }

}



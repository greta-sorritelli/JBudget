package it.unicam.cs.pa.jbudget104952.javaController;

import it.unicam.cs.pa.jbudget104952.javaModel.Tag;
import it.unicam.cs.pa.jbudget104952.javaModel.Transaction;
import it.unicam.cs.pa.jbudget104952.javaModel.Account;
import it.unicam.cs.pa.jbudget104952.javaModel.AccountType;
import it.unicam.cs.pa.jbudget104952.javaModel.Ledger;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.function.Predicate;

/**
 * Interfaccia per il controller del {@link Ledger}.
 * Si occupa di gestire i dati e le operazioni principali.
 *
 * @author Greta Sorritelli
 */
public interface LedgerController {

    /**
     *
     * @return lista di Account
     */
    List<Account> getAccount();

    /**
     * Aggiunge un Account.
     * @param id id dell'Account da aggiungere
     * @param type tipo dell'Account da aggiungere
     * @param name nome dell'Account da aggiungere
     * @param description descrizione dell'Account da aggiungere
     * @param opening balance iniziale dell'Account da aggiungere
     */
    void addAccount(int id, AccountType type, String name, String description, double opening);

    /**
     * Rimuove un Account.
     * @param account Account da rimuovere
     */
    void removeAccount(Account account);

    /**
     * Aggiunta di una Transaction.
     * @param t Transaction da aggiungere
     * @return Transaction aggiunta
     */
    Transaction addTransaction(Transaction t);

    /**
     *
     * @return lista di Transaction
     */
    List<Transaction> getTransactions();

    /**
     * Ritorna le Transaction con un predicato.
     * @param p predicato
     * @return lista di Transaction
     */
    List<Transaction> getTransactions(Predicate<Transaction> p);

    /**
     * Rimuove una Transaction.
     * @param transaction Transaction da rimuovere
     */
    void removeTransaction(Transaction transaction);

    /**
     *
     * @return lista di Tag
     */
    List<Tag> getTags();

    /**
     * Aggiunge un Tag.
     * @param id id del Tag da aggiungere
     * @param name nome del Tag da aggiungere
     * @param description descrizione del Tag da aggiungere
     */
    void addTag(int id, String name, String description);

    /**
     *
     * @param tag Tag da rimuovere
     */
    void removeTag(Tag tag);

    /**
     * Salva i dati in un file
     * @param path path del file
     */
    void saveAsTxt(String path) throws IOException;

    /**
     * Importa i dati da un file
     * @param path path del file
     */
    void importAsTxt(String path) throws IOException, ParseException;
}

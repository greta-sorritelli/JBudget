package it.unicam.cs.pa.jbudget104952.javaModel;


import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Objects;

/**
 * {@link SimpleTransaction} implementa {@link Transaction} e crea una transazione.
 *
 * @author Greta Sorritelli
 */
public class SimpleTransaction implements Transaction {


    private final int ID;
    private final List<Tag> tags;
    private final List<Movement> movements;
    private final GregorianCalendar date;

    /**
     * Costruttore di una Transaction.
     *
     * @param ID   id della Transaction
     * @param date data della Transaction
     * @throws IllegalArgumentException se i parametri sono errati
     */
    public SimpleTransaction(int ID, GregorianCalendar date) {
        if (ID < 0 || date == null)
            throw new IllegalArgumentException("Invalid elements.");
        this.ID = ID;
        this.date = date;
        tags = new ArrayList<>();
        movements = new ArrayList<>();
    }

    /**
     * Ritorna true se due {@link SimpleTransaction} equivalgono.
     *
     * @param o un oggetto
     * @return true se equivalgono, false altrimenti.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SimpleTransaction that = (SimpleTransaction) o;
        return ID == that.ID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID);
    }

    /**
     * Aggiunge un Tag alla Transaction e ai Movement presenti.
     *
     * @param t Tag da aggiungere
     * @throws NullPointerException se impossibile aggiungere il tag
     */
    @Override
    public void addTag(Tag t) {
        if (t == null)
            throw new NullPointerException();
        if (!tags.contains(t))
            this.tags.add(t);
        for (Movement movement : this.getMovements()) {
            if (!movement.getTag().contains(t))
                movement.getTag().add(t);
        }
    }

    /**
     * Rimuove un Tag alla Transaction e ai Movement presenti.
     *
     * @param t Tag da rimuovere
     */
    @Override
    public void removeTag(Tag t) {
        if (tags.contains(t))
            this.tags.remove(t);
        for (Movement movement : this.getMovements()) {
            movement.getTag().remove(t);
        }
    }

    /**
     * @return la data della Transaction
     */
    @Override
    public GregorianCalendar getDate() {
        return this.date;
    }


    /**
     * Serve per calcolare l'amount complessivo della transazione.
     *
     * @return amount
     */
    @Override
    public double getTotalAmount() {
        double totAmount = 0;
        for (Movement movement : this.getMovements()) {
            switch (movement.getType()) {
                case DEBIT:
                    totAmount -= movement.getAmount();
                    break;
                case CREDITS:
                    totAmount += movement.getAmount();
                    break;
            }
        }
        return totAmount;
    }

    /**
     * @return lista dei Movement presenti
     */
    @Override
    public List<Movement> getMovements() {
        return this.movements;
    }

    /**
     * @return lista dei Tag associati
     */
    @Override
    public List<Tag> getTags() {
        return this.tags;
    }

    /**
     * @return id della Transaction
     */
    @Override
    public int getID() {
        return this.ID;
    }

    /**
     * Aggiunge un Movement alla Transaction
     *
     * @param movement Movement da aggiungere
     * @return Movement aggiunto
     */
    @Override
    public Movement addMovement(Movement movement) {
        if (!this.getMovements().contains(movement)) {
            this.getMovements().add(movement);
            movement.setTransaction(this);
        }
        return movement;
    }

    /**
     * Rimuove un Movement dalla Transaction
     *
     * @param m Movement da rimuovere
     * @throws IllegalStateException se impossibile rimuovere il movimento
     */
    @Override
    public void removeMovement(Movement m) {
        if (m == null || !movements.contains(m))
            throw new IllegalStateException("Wrong movement.");
        this.movements.remove(m);
    }

    @Override
    public String toString() {
        return "{" + ID + ", " + date.getTime().toString() + '}';
    }
}

package it.unicam.cs.pa.jbudget104952.javaFX;

import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;

/**
 * Classe per la creazione di una Transaction e i relativi Movement presenti in esso.
 *
 * @author Greta Sorritelli
 */
public class JavaFXAddTransaction {

    private final SimpleLedgerController controller;

    public JavaFXAddTransaction(SimpleLedgerController controller) {
        this.controller = controller;
    }

    /**
     * Transaction da creare e a cui associare nuovi Movement
     */
    private Transaction transaction;

    @FXML
    TabPane tabPane;
    @FXML
    Tab tabTrans;
    @FXML
    Tab tabMov;


    @FXML
    TextField transactionID;
    @FXML
    DatePicker transactionData;


    @FXML
    TableView<Movement> movementTableView;
    @FXML
    TableColumn<Movement, Integer> movementID;
    @FXML
    TableColumn<Movement, MovementsType> movementType;
    @FXML
    TableColumn<Movement, String> movementDescription;
    @FXML
    TableColumn<Movement, Account> movementAccount;
    @FXML
    TableColumn<Movement, Double> movementAmount;
    @FXML
    TableColumn<Movement, List<Tag>> movementsTags;


    /**
     * Aggiorna i dati della tabella relativa ai Movement della Transaction.
     */
    @FXML
    public void movementRefresh() {
        setMovementCellValueFactory();
        movementTableView.getItems().clear();
        for (Movement movement : transaction.getMovements())
            movementTableView.getItems().add(movement);
    }

    /**
     * Riempie la tabella con i dati dei Movement.
     */
    private void setMovementCellValueFactory() {
        movementTableView.setEditable(true);
        movementTableView.getSelectionModel().setSelectionMode(
                SelectionMode.MULTIPLE
        );
        movementID.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getID()));
        movementType.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getType()));
        movementDescription.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getDescription()));
        movementAccount.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getAccount()));
        movementAmount.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getAmount()));
        movementsTags.setCellValueFactory(movement -> new SimpleObjectProperty<>((movement.getValue().getTag())));
    }

    /**
     * Inizializzazione della Transaction con relativo {@code ID} e {@code Date}.
     */
    private void setTransaction() {
        if (transaction == null) {
            int id = Integer.parseInt(transactionID.getText());
            LocalDate date = transactionData.getValue();
            ZonedDateTime zonedDateTime = date.atStartOfDay(ZoneId.systemDefault());
            GregorianCalendar gc = GregorianCalendar.from(zonedDateTime);
            transaction = new SimpleTransaction(id, gc);
        }
    }

    /**
     * Salvataggio della Transaction e i relativi Movement.
     * Una Transaction deve contenere almeno un Movement.
     */
    @FXML
    public void saveTransaction() {
        try {
            if (transaction.getMovements().size() > 0) {
                transaction.getTotalAmount();
                controller.addTransaction(transaction);
                transaction = null;
                Stage stage = (Stage) transactionData.getScene().getWindow();
                stage.close();
            } else
                throw new IllegalArgumentException();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Invalid Transaction.");
            alert.showAndWait();
            e.printStackTrace();
        }
    }

    /**
     * Inizializza la Transaction se necessario e apre il Tab relativo all'aggiunta del Movement.
     */
    @FXML
    public void addNewMovement() {
        try {
            setTransaction();
            fillListAccounts();
            transactionID.setEditable(false);
            transactionID.setDisable(true);
            transactionData.setDisable(true);
            transactionData.getEditor().setEditable(false);
            tabPane.getSelectionModel().select(tabMov);
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Invalid Transaction.");
            alert.showAndWait();
            e.printStackTrace();
        }

    }

    /**
     * Rimozione di uno o piu Movement della Transaction.
     */
    @FXML
    public void removeMovement() {
        List<Movement> sel = new ArrayList<>(movementTableView.getSelectionModel().getSelectedItems());
        for (Movement mov : sel) {
            if (mov != null)
                transaction.removeMovement(mov);
        }
        movementTableView.getItems().removeAll(sel);
        movementRefresh();
    }


    @FXML
    TextField id;
    @FXML
    TextField description;
    @FXML
    ChoiceBox<MovementsType> type;
    final ObservableList<MovementsType> types = FXCollections.observableArrayList(MovementsType.CREDITS, MovementsType.DEBIT);
    @FXML
    TextField amount;
    @FXML
    ChoiceBox<String> account = new ChoiceBox<>();
    final ObservableList<String> accounts = FXCollections.observableArrayList();


    private void fillListAccounts() {
        for (Account a : controller.getAccount()) {
            accounts.add(a.getName());
        }
    }


    @FXML
    public void initType() {
        type.setItems(types);
    }

    @FXML
    public void initAccount() {
        account.setItems(accounts);
    }

    private void clear() {
        id.clear();
        description.clear();
        amount.clear();
    }

    /**
     * Inizializza un Movement e lo salva nella Transaction.
     */
    @FXML
    public void saveMovement() {
        try {
            setTransaction();
            int ID = Integer.parseInt(id.getText());
            double amount1 = Double.parseDouble(amount.getText());
            MovementsType type1 = type.getValue();
            for (Account acc : controller.getAccount()) {
                if (acc.getName().equals(account.getValue())) {
                    Movement m = new SimpleMovement(ID, description.getText(), type1, acc, amount1);
                    if (controller.control(m)) {
                        transaction.addMovement(m);
                    } else {
                        throw new IllegalArgumentException();
                    }
                }
            }
            movementRefresh();
            tabPane.getSelectionModel().select(tabTrans);
            clear();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Invalid Movement.");
            alert.showAndWait();
            e.printStackTrace();

        }
    }


}

package it.unicam.cs.pa.jbudget104952.javaFX;

/**
 * Interfaccia per la rimozione dei Tag.
 *
 * @author Greta Sorritelli
 */
public interface JavaFXRemoveTag {

    void removeTag();
    
}

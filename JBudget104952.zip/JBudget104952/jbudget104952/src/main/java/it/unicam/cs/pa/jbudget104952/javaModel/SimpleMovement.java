package it.unicam.cs.pa.jbudget104952.javaModel;


import java.util.ArrayList;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.Objects;

/**
 * La classe {@link SimpleMovement} implementa {@link Movement} e serve a creare un
 * movimento. Ogni movimento fa parte di una transazione.
 *
 * @author Greta Sorritelli
 */
public class SimpleMovement implements Movement {


    private final int ID;
    private final String description;
    private final MovementsType type;
    private Transaction transaction;
    private final Account account;
    private final List<Tag> tag;
    private GregorianCalendar date;
    private final double amount;

    /**
     * Costruttore di un Movement.
     * @param ID id del Movement
     * @param description descrizione del Movement
     * @param type tipo del Movement
     * @param account account del Movement
     * @param amount amount del Movement
     * @throws NullPointerException se i parametri sono nulli
     * @throws IllegalArgumentException se l'amount è errato
     */
    public SimpleMovement(int ID, String description, MovementsType type, Account account, double amount) {
        if (type == null || account == null)
            throw new NullPointerException("Null elements.");
        if (amount <= 0 || ID < 0)
            throw new IllegalArgumentException("Wrong amount.");
        this.ID = ID;
        this.description = description;
        this.type = type;
        this.account = account;
        this.amount = amount;
        this.date = null;
        this.transaction = null;
        tag = new ArrayList<>();
    }

    /**
     * Ritorna true se due {@link SimpleMovement} equivalgono.
     * @param o un oggetto
     * @return true se equivalgono, false altrimenti.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        SimpleMovement simpleMovement = (SimpleMovement) o;
        return ID == simpleMovement.ID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID);
    }

    /**
     *
     * @return l'amount del Movement
     */
    @Override
    public double getAmount() {
        return this.amount;
    }

    /**
     *
     * @return la descrizione del Movement
     */
    @Override
    public String getDescription() {
        return this.description;
    }

    /**
     *
     * @return il tipo del Movement
     */
    @Override
    public MovementsType getType() {
        return this.type;
    }

    /**
     *
     * @return la Transaction di cui fa parte
     */
    @Override
    public Transaction getTransactions() {
        return this.transaction;
    }

    /**
     *
     * @return l'Account associato al Movement
     */
    @Override
    public Account getAccount() {
        return this.account;
    }

    /**
     *
     * @return la data del Movement
     */
    @Override
    public GregorianCalendar getDate() {
        return this.date;
    }

    /**
     *
     * @return i Tag associati al Movement
     */
    @Override
    public List<Tag> getTag() {
        return this.tag;
    }

    /**
     *
     * @return l'ID del Movement
     */
    @Override
    public int getID() {
        return this.ID;
    }

    /**
     * Associa il Movement ad una Transaction
     * @param transaction Transaction da aggiornare
     */
    @Override
    public void setTransaction(Transaction transaction) {
        this.transaction = transaction;
        this.date = transaction.getDate();
    }

    /**
     * Aggiunge un Tag al Movement
     * @param tag Tag da aggiungere
     */
    @Override
    public void addTag(Tag tag) {
        if (!this.tag.contains(tag) && tag != null)
            this.tag.add(tag);
    }

    /**
     * Rimuove un Tag dal Movement
     * @param tag Tag da rimuovere
     */
    @Override
    public void removeTag(Tag tag) {
        if (tag != null)
            this.tag.remove(tag);
    }

    @Override
    public String toString() {
        return "{" + ID + ", " +  type +  ", " + account + ", " + amount + '}';
    }
}
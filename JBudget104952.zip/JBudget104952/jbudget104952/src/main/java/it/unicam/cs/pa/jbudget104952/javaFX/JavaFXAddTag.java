package it.unicam.cs.pa.jbudget104952.javaFX;


/**
 * Interfaccia per la creazione di una finestra di aggiunta per Tag.
 *
 * @author Greta Sorritelli
 */
public interface JavaFXAddTag {

    void saveTag();

}

package it.unicam.cs.pa.jbudget104952.javaPersistence;

import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.Account;
import it.unicam.cs.pa.jbudget104952.javaModel.Movement;
import it.unicam.cs.pa.jbudget104952.javaModel.Tag;
import it.unicam.cs.pa.jbudget104952.javaModel.Transaction;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Classe per il salvataggio su file txt
 *
 * @author Greta Sorritelli
 */
public class SaverTxt implements Saver {

    private final SimpleLedgerController controller;

    private final String accountsPath;

    private  final String transactionsPath;

    private final String movementsPath;

    private final String tagsPath;

    /**
     * Imposta il path per ogni file su cui salvare i dati
     * @param directory directory della cartella in cui posizionare i file
     * @param controller il controller del ledger
     */
    public SaverTxt(String directory, SimpleLedgerController controller) {
        this.controller = controller;
        accountsPath = directory + File.separator + "Accounts.txt";
        transactionsPath = directory + File.separator + "Transactions.txt";
        movementsPath = directory + File.separator + "Movements.txt";
        tagsPath = directory + File.separator + "Tags.txt";
    }

    /**
     * Si occupa di salvare tutti gli oggetti.
     * @throws IOException eccezione del path
     */
    @Override
    public void saveAll() throws IOException {
        saveAccount();
        saveTags();
        saveTransactions();
        saveMovement();
    }

    /**
     * Salvataggio di un Account in una lista di stringhe.
     * @throws IOException eccezione del path del file
     */
    public void saveAccount() throws IOException {
        List<String> accounts = getAccountsToSave();
        BufferedWriter writer = new BufferedWriter(new FileWriter(accountsPath));
        writer.write("");
        for(String account : accounts) {
            writer.append(account);
            writer.newLine();
        }
        writer.flush();
        writer.close();
    }

    /**
     * Salvataggio di una Transaction in una lista di stringhe.
     * @throws IOException eccezione del path del file
     */
    public void saveTransactions() throws IOException {
        List<String> transactions = getTransactionsToSave();
        BufferedWriter writer = new BufferedWriter(new FileWriter(transactionsPath));
        writer.write("");
        for(String transaction : transactions) {
            writer.append(transaction);
            writer.newLine();
        }
        writer.flush();
        writer.close();
    }

    /**
     * Salvataggio di un Movement in una lista di stringhe.
     * @throws IOException eccezione del path del file
     */
    public void saveMovement() throws IOException {
        List<String> movements = getMovementsToSave();
        BufferedWriter writer = new BufferedWriter(new FileWriter(movementsPath));
        writer.write("");
        for(String movement : movements) {
            writer.append(movement);
            writer.newLine();
        }
        writer.flush();
        writer.close();
    }

    /**
     * Salvataggio di un Tag in una lista di stringhe.
     * @throws IOException eccezione del path del file
     */
    public void saveTags() throws IOException {
        List<String> tags = getTagsToSave();
        BufferedWriter writer = new BufferedWriter(new FileWriter(tagsPath));
        writer.write("");
        for(String tag : tags) {
            writer.append(tag);
            writer.newLine();
        }
        writer.flush();
        writer.close();
    }


    /**
     * @return i tag del ledger da salvare
     */
    private List<String> getTagsToSave() {
        List<String> tagsToSave = new ArrayList<>();
        controller.getTags().forEach(tag -> tagsToSave.add(stringTag(tag)));
        return tagsToSave;
    }

    /**
     * @return i movimenti di ogni transazione del ledger da salvare
     */
    private List<String> getMovementsToSave() {
        List<String> movementsToSave = new ArrayList<>();
        for (Transaction transaction : controller.getTransactions()) {
            transaction.getMovements().forEach(movement -> movementsToSave.add(stringMovement(movement)));
        }
        return movementsToSave;
    }

    /**
     * @return le transazioni del ledger da salvare
     */
    private List<String> getTransactionsToSave() {
        List<String> transactionToSave = new ArrayList<>();
        controller.getTransactions().forEach(transaction -> transactionToSave.add(stringTransaction(transaction)));
        return transactionToSave;
    }

    /**
     * @return gli account del ledger da salvare
     */
    private List<String> getAccountsToSave() {
        List<String> accountsToSave = new ArrayList<>();
        controller.getAccount().forEach(account -> accountsToSave.add(stringAccount(account)));
        return accountsToSave;
    }

    private String stringTag(Tag tag) {
        return tag.getID() + ";" + tag.getName() + ";" + tag.getDescription();
    }

    private String stringMovement(Movement movement) {
        return movement.getID() + ";" + movement.getDescription() + ";" + movement.getType() + ";" + movement.getAccount().getID()
                + ";" + movement.getAmount() + ";" + movement.getTransactions().getID() + ";" + movement.getTag();
    }

    private String stringTransaction(Transaction transaction) {
        return transaction.getID() + ";" + format(transaction.getDate()) + ";" + transaction.getTags();
    }

    private String stringAccount(Account account) {
        return account.getID() + ";" + account.getType() + ";" + account.getName() + ";" + account.getDescription() + ";" + account.getOpeningBalance();

    }

    /**
     * Formatta una data GregorianCalendar in stringa.
     *
     * @param date data da convertire
     * @return la stringa della data
     */
    private String format(GregorianCalendar date) {
        SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");
        Date date1 = date.getTime();
        return fmt.format(date1);
    }

}

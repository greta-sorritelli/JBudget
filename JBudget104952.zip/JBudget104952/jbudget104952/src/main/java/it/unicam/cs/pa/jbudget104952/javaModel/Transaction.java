package it.unicam.cs.pa.jbudget104952.javaModel;


import java.util.GregorianCalendar;
import java.util.List;

/**
 * Una {@link Transaction} definisce una transazione, cioè un insieme di
 * movimenti.
 * 
 * @author Greta Sorritelli
 *
 */
public interface Transaction {

	int getID();

	List<Movement> getMovements();

	List<Tag> getTags();

	GregorianCalendar getDate();

	double getTotalAmount();

	Movement addMovement(Movement movement);

	void removeMovement(Movement m);

	void addTag(Tag t);

	void removeTag(Tag t);

}

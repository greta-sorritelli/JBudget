package it.unicam.cs.pa.jbudget104952;


import it.unicam.cs.pa.jbudget104952.javaFX.JavaFXJBudget;
import javafx.application.Application;

/**
 * Classe principale per il launch di un'interfaccia grafica.
 *
 * @author Greta Sorritelli
 */
public class App {

    public static void main(String[] args) {
        if (args.length == 0)
            launchGui();
    }

    private static void launchGui() {
        Application.launch(JavaFXJBudget.class);
    }

}

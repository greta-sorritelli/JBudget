package it.unicam.cs.pa.jbudget104952.javaModel;

/**
 * Un {@link Account} può essere di due tipi:
 * 
 * {@code ASSETS} per le risorse {@code LIABILITIES} per i debiti
 * 
 * @author Greta Sorritelli
 *
 */
public enum AccountType {

	ASSETS, LIABILITIES

}

package it.unicam.cs.pa.jbudget104952.javaFX;


import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Aggiunta di un Tag al ledger. Implementa l'interfaccia {@link JavaFXAddTag}.
 *
 * @author Greta Sorritelli
 */
public class JavaFXAddTagLedger implements JavaFXAddTag {

    private final SimpleLedgerController controller;

    public JavaFXAddTagLedger(SimpleLedgerController controller) {
        this.controller = controller;
    }

    @FXML
    TextField tagID;
    @FXML
    TextField tagName;
    @FXML
    TextField tagDescription;



    /**
     * Metodo per la creazione di un Tag e la relativa aggiunta al ledger.
     */
    @Override
    @FXML
    public void saveTag() {
        try {
            int id = Integer.parseInt(tagID.getText());
            String name = tagName.getText();
            String description = tagDescription.getText();
            controller.addTag(id, name, description);
            Stage stage = (Stage) tagID.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Invalid Tag.");
            alert.showAndWait();
            e.printStackTrace();
        }
    }


}

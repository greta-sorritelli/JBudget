package it.unicam.cs.pa.jbudget104952.javaPersistence;

import java.io.IOException;

/**
 * Fornisce un metodo generale per il salvataggio su file.
 *
 * @author Greta Sorritelli
 */
public interface Saver {

    void saveAll() throws IOException;

}

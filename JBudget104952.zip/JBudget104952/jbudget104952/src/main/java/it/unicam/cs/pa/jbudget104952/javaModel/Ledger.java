package it.unicam.cs.pa.jbudget104952.javaModel;

import java.util.List;
import java.util.function.Predicate;

/**
 * Un {@link Ledger} è un libro mastro per la gestione delle proprie finanze.
 * 
 * @author Greta Sorritelli
 *
 */
public interface Ledger {

	List<Account> getAccount();

	List<Transaction> getTransactions();

	List<Transaction> getTransactions(Predicate<Transaction> p);

	List<Tag> getTags();

	Account addAccount(int ID, AccountType type, String name, String description, double opening);

    void removeAccount(Account account);

    Transaction addTransaction(Transaction t);

	Tag addTag(int id, String name, String description);

	void removeTransaction(Transaction transaction);

	void removeTag(Tag tag);

}

package it.unicam.cs.pa.jbudget104952.javaFX;

public interface JavaFXFilter {

    void filter();

    void reset();

}

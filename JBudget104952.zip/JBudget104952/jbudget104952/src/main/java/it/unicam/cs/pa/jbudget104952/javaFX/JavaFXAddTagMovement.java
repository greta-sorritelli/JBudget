package it.unicam.cs.pa.jbudget104952.javaFX;

import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.Movement;
import it.unicam.cs.pa.jbudget104952.javaModel.Tag;
import it.unicam.cs.pa.jbudget104952.javaModel.Transaction;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.stage.Stage;

/**
 * Classe per l'aggiunta di un Tag ad un movimento. Implementa l'interfaccia {@link JavaFXAddTag}.
 *
 * @author Greta Sorritelli
 */
public class JavaFXAddTagMovement implements JavaFXAddTag {

    private final SimpleLedgerController controller;

    public JavaFXAddTagMovement(SimpleLedgerController controller) {
        this.controller = controller;
    }


    @FXML
    ChoiceBox<Tag> choiceTag;
    @FXML
    ChoiceBox<Movement> choiceMovement;


    @FXML
    public void initTag() {
        ObservableList<Tag> tags = FXCollections.observableArrayList(controller.getTags());
        choiceTag.setItems(tags);
    }

    @FXML
    public void initMovement() {
        ObservableList<Movement> mov = FXCollections.observableArrayList();
        for (Transaction t : controller.getTransactions()) {
            mov.addAll(t.getMovements());
        }
        choiceMovement.setItems(mov);
    }


    /**
     * Aggiunta di un Tag ad un Movement.
     */
    @Override
    @FXML
    public void saveTag() {
        try {
            Tag tag = choiceTag.getValue();
            Movement movement = choiceMovement.getValue();
            movement.addTag(tag);
            Stage stage = (Stage) choiceMovement.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }


}

package it.unicam.cs.pa.jbudget104952.javaModel;


import java.util.Objects;

/**
 * {@link SimpleTag} implementa {@link Tag} e crea una categoria per un movimento o
 * transazione.
 *
 * @author Greta Sorritelli
 */
public class SimpleTag implements Tag {

    private final int ID;
    private String description;
    private String name;

    /**
     * Costruttore per un Tag.
     * @param ID id del Tag
     * @param name nome del Tag
     * @param description descrizione del Tag
     * @throws IllegalArgumentException se l'ID non è valido
     * @throws NullPointerException se il nome è nullo
     */
    public SimpleTag(int ID, String name, String description) {
        if (ID < 0)
            throw new IllegalArgumentException("Invalid ID.");
        if (name == null)
            throw new NullPointerException("Invalid name.");
        this.ID = ID;
        this.name = name.toUpperCase();
        this.description = description;
    }

    /**
     * Ritorna true se due {@link SimpleTag} equivalgono.
     * @param o un oggetto
     * @return true se equivalgono, false altrimenti.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;
        SimpleTag simpleTag = (SimpleTag) o;
        return ID == simpleTag.ID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID);
    }

    /**
     *
     * @return la descrizione del Tag
     */
    @Override
    public String getDescription() {
        return this.description;
    }

    /**
     * Imposta la descrizione del Tag
     * @param desc descrizione da impostare
     */
    @Override
    public void setDescription(String desc) {
        this.description = desc;
    }

    /**
     *
     * @return il nome del Tag
     */
    @Override
    public String getName() {
        return this.name;
    }

    /**
     * Imposta il nome del Tag
     * @param name nome da impostare
     */
    @Override
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return id del Tag
     */
    @Override
    public int getID() {
        return this.ID;
    }


    @Override
    public String toString() {
        return "{" + name + '}';
    }
}

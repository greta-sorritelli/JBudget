package it.unicam.cs.pa.jbudget104952.javaModel;

import java.util.List;
import java.util.function.Predicate;

/**
 * Un {@link Account} è un tipo di conto con un saldo e dei movimenti ad esso
 * associati.
 * 
 * @author Greta Sorritelli
 *
 */
public interface Account {

	int getID();

	String getName();

	String getDescription();

	AccountType getType();

	double getOpeningBalance();

	double getBalance();

	void refreshBalance(Movement movement);

	void addAmount(double amount);

	void subtractAmount(double amount);

    void revertBalance(Movement movement);

    void setBalance(double b);

	List<Movement> getMovements();

	List<Movement> getMovements(Predicate<Movement> p);
}

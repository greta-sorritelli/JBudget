package it.unicam.cs.pa.jbudget104952.javaFX;

import it.unicam.cs.pa.jbudget104952.javaModel.Movement;
import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.Tag;
import it.unicam.cs.pa.jbudget104952.javaModel.Transaction;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.stage.Stage;

/**
 * Classe per la rimozione di un Tag da un Movement. Implementa l'interfaccia {@link JavaFXRemoveTag}.
 *
 * @author Greta Sorritelli
 */
public class JavaFXRemoveTagMovement implements JavaFXRemoveTag{


    private final SimpleLedgerController controller;

    public JavaFXRemoveTagMovement(SimpleLedgerController controller) {
        this.controller = controller;
    }

    @FXML
    ChoiceBox<Tag> choiceTag;
    @FXML
    ChoiceBox<Movement> choiceMovement;

    @FXML
    public void initTag() {
        ObservableList<Tag> tags = FXCollections.observableArrayList(controller.getTags());
        choiceTag.setItems(tags);
    }

    @FXML
    public void initMovement() {
        ObservableList<Movement> mov = FXCollections.observableArrayList();
        for (Transaction t : controller.getTransactions()) {
            mov.addAll(t.getMovements());
        }
        choiceMovement.setItems(mov);
    }

    /**
     * Rimozione del Tag dal Movement.
     */
    @Override
    @FXML
    public void removeTag() {
        try {
            Tag tag = choiceTag.getValue();
            Movement movement = choiceMovement.getValue();
            for (Transaction t : controller.getTransactions()) {
                for (Movement m : t.getMovements()) {
                    if (m.equals(movement) && m.getTag().contains(tag)) {
                        m.removeTag(tag);
                    }
                }
            }
            Stage stage = (Stage) choiceMovement.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.showAndWait();
            e.printStackTrace();
        }
    }

}

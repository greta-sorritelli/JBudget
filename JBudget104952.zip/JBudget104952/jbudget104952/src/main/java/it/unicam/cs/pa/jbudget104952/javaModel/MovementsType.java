package it.unicam.cs.pa.jbudget104952.javaModel;

/**
 * Un {@link Movement} può essere di due tipi:
 * 
 * {@code DEBIT} per i movimenti in uscita, {@code CREDITS} per i movimenti in
 * entrata
 * 
 * @author Greta Sorritelli
 *
 */
public enum MovementsType {

	DEBIT, CREDITS

}

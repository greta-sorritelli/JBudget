package it.unicam.cs.pa.jbudget104952.javaModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * La classe {@link SimpleAccount} serve a creare un conto, implementa {@link Account}.
 *
 * @author Greta Sorritelli
 */
public class SimpleAccount implements Account {

    private final int ID;
    private final String name;
    private final String description;
    private final AccountType type;
    private final double openingBalance;
    private final List<Movement> movements;
    private double balance;

    /**
     * Costruttore di un Account.
     *
     * @param id id relativo all'Account
     * @param type tipo dell'Account
     * @param name nome dell'Account
     * @param description descrizione dell'Account
     * @param openingBalance balance iniziale dell'Account
     * @throws NullPointerException se i parametri sono nulli
     * @throws IllegalArgumentException se i parametri sono errati
     *
     */
    public SimpleAccount(int id, AccountType type, String name, String description, double openingBalance) {
        if (type == null || name == null)
            throw new NullPointerException("Null elements.");
        if (openingBalance < 0 || id < 0)
            throw new IllegalArgumentException("Illegal elements.");
        this.ID = id;
        this.name = name.toUpperCase();
        this.type = type;
        this.description = description;
        this.openingBalance = openingBalance;
        this.balance = openingBalance;
        movements = new ArrayList<>();
    }

    /**
     * Ritorna true se due {@link SimpleAccount} equivalgono.
     * @param o un oggetto
     * @return true se equivalgono, false altrimenti.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        SimpleAccount that = (SimpleAccount) o;
        return ID == that.ID;
    }

    @Override
    public int hashCode() {
        return Objects.hash(ID);
    }

    /**
     *
     * @return il nome dell'Account
     */
    @Override
    public String getName() {
        return this.name;
    }

    /**
     *
     * @return la descrizione dell'Account
     */
    @Override
    public String getDescription() {
        return this.description;
    }

    /**
     *
     * @return il balance iniziale dell'Account
     */
    @Override
    public double getOpeningBalance() {
        return this.openingBalance;
    }

    /**
     *
     * @return il balance attuale dell'Account
     */
    @Override
    public double getBalance() {
        return this.balance;
    }

    /**
     * Aggiorna il valore del balance dopo l'aggiunta di un Movement.
     * @param movement il Movement aggiunto
     */
    @Override
    public void refreshBalance(Movement movement) {
            MovementsType type = movement.getType();
            switch (type) {
                case DEBIT:
                    switch (this.getType()) {
                        case ASSETS:
                            this.subtractAmount(movement.getAmount());
                            break;
                        case LIABILITIES:
                            this.addAmount(movement.getAmount());
                            break;
                        default:
                            break;
                    }
                    break;
                case CREDITS:
                    switch (this.getType()) {
                        case ASSETS:
                            this.addAmount(movement.getAmount());
                            break;
                        case LIABILITIES:
                            this.subtractAmount(movement.getAmount());
                            break;
                        default:
                            break;
                    }
                    break;
            }
        }

    /**
     * Aggiorna il valore del balance dopo la rimozione di un Movement.
     * @param movement il Movement rimosso
     */
    @Override
    public void revertBalance(Movement movement) {
        MovementsType type = movement.getType();
        switch (type) {
            case DEBIT:
                switch (this.getType()) {
                    case ASSETS:
                        this.addAmount(movement.getAmount());
                        break;
                    case LIABILITIES:
                        this.subtractAmount(movement.getAmount());
                        break;
                    default:
                        break;
                }
                break;
            case CREDITS:
                switch (this.getType()) {
                    case ASSETS:
                        this.subtractAmount(movement.getAmount());
                        break;
                    case LIABILITIES:
                        this.addAmount(movement.getAmount());
                        break;
                    default:
                        break;
                }
                break;
        }
    }

    /**
     * Imposta il valore del balance
     * @param b valore del nuovo balance
     */
    @Override
    public void setBalance(double b) {
        this.balance = b;
    }

    /**
     *
     * @return la lista dei Movement relativi all'Account
     */
    @Override
    public List<Movement> getMovements() {
        return this.movements;
    }

    /**
     * Ritorna la lista dei Movement con un determinato predicato.
     * @param p predicato
     * @return lista di Movement
     */
    @Override
    public List<Movement> getMovements(Predicate<Movement> p) {
        Stream<Movement> m = this.movements.stream();
        return m.filter(p).collect(Collectors.toList());
    }

    /**
     * @return il tipo di Account
     */
    @Override
    public AccountType getType() {
        return this.type;
    }

    /**
     * Aggiunge l'amount di un movimento al {@code balance} del conto
     */
    @Override
    public void addAmount(double amount) {
        if (amount > 0)
            this.balance += amount;
    }

    /**
     * Sottrae l'amount di un movimento al {@code balance} del conto
     */
    @Override
    public void subtractAmount(double amount) {
        if (balance >= amount && amount > 0)
            this.balance -= amount;
        else
            throw new IllegalArgumentException("Illegal amount.");
    }

    /**
     *
     * @return l'ID dell'Account
     */
    @Override
    public int getID() {
        return this.ID;
    }

    @Override
    public String toString() {
        return "{" + name + ", " + type + ", " + ID + "}";
    }
}

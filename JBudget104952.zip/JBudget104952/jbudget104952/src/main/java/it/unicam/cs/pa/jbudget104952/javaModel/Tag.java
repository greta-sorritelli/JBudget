package it.unicam.cs.pa.jbudget104952.javaModel;

/**
 * {@link Tag} definisce una categoria con nome e descrizione.
 * 
 * @author Greta Sorritelli
 *
 */
public interface Tag {

    int getID();

	String getDescription();

	String getName();

	void setName(String name);

	void setDescription(String desc);

}

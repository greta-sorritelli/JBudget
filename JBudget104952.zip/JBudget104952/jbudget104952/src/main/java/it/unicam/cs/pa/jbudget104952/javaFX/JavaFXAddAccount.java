package it.unicam.cs.pa.jbudget104952.javaFX;

import it.unicam.cs.pa.jbudget104952.javaModel.AccountType;
import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Questa classe serve per aggiungere un account al ledger.
 *
 * @author Greta Sorritelli
 */
public class JavaFXAddAccount {

    private final SimpleLedgerController controller;

    public JavaFXAddAccount(SimpleLedgerController controller) {
        this.controller = controller;
    }

    @FXML
    ChoiceBox<AccountType> accountTypeChoiceBox = new ChoiceBox<>();
    final ObservableList<AccountType> accountTypes = FXCollections.observableArrayList(AccountType.ASSETS, AccountType.LIABILITIES);
    @FXML
    TextField accountID;
    @FXML
    TextField accountName;
    @FXML
    TextField accountDescription;
    @FXML
    TextField accountOpeningBalance;


    @FXML
    public void initialize() {
        accountTypeChoiceBox.setValue(AccountType.ASSETS);
        accountTypeChoiceBox.setItems(accountTypes);
    }

    /**
     * Salvo un Account e lo aggiungo nel ledger.
     */
    @FXML
    public void saveAccount() {
        try {
            int id = Integer.parseInt(accountID.getText());
            AccountType type = accountTypeChoiceBox.getValue();
            String name = accountName.getText();
            String description = accountDescription.getText();
            double op = Double.parseDouble(accountOpeningBalance.getText());
            controller.addAccount(id, type, name, description, op);
            Stage stage = (Stage) accountTypeChoiceBox.getScene().getWindow();
            stage.close();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setContentText("Invalid Account.");
            alert.showAndWait();
            e.printStackTrace();
        }
    }


}

package it.unicam.cs.pa.jbudget104952.javaFX;

import javafx.application.Application;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.stage.StageStyle;

/**
 * Classe principale per la GUI JavaFX. Estende {@link Application}.
 *
 * @author Greta Sorritelli
 */
public class JavaFXJBudget extends Application {

    /**
     * Apre la finestra principale.
     * @param stage stage
     * @throws Exception eccezione
     */

    @Override
    public void start(Stage stage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("/JBudgetHome.fxml"));
        stage.setTitle("JBudget");
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.initStyle(StageStyle.DECORATED);
        Image ico = new Image("/money.png");
        stage.getIcons().add(ico);
        stage.resizableProperty().set(false);
        stage.show();
    }

}

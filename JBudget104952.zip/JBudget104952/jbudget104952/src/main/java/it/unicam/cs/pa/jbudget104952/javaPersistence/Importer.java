package it.unicam.cs.pa.jbudget104952.javaPersistence;

import java.io.IOException;
import java.text.ParseException;

/**
 * Fornisce un metodo generale per l'importazione da file.
 *
 * @author Greta Sorritelli
 */
public interface Importer {

    void importAll() throws IOException, ParseException;

}

package it.unicam.cs.pa.jbudget104952.javaController;

import it.unicam.cs.pa.jbudget104952.javaPersistence.ImporterTxt;
import it.unicam.cs.pa.jbudget104952.javaPersistence.SaverTxt;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.util.function.Predicate;

/**
 * Classe controller per il ledger.
 *
 * @author Greta Sorritelli
 */
public class SimpleLedgerController implements LedgerController {

    private final SimpleLedger ledger = new SimpleLedger();


    /**
     * Controlla se un Movement può essere effettuato, relativamente al balance dell'Account.
     *
     * @param m Movement da effettuare
     * @return true se può essere aggiunto, false altrimenti
     */
    public boolean control(Movement m) {
        MovementsType mt = m.getType();
        AccountType at = m.getAccount().getType();
        boolean checked = true;
        if ((mt.equals(MovementsType.CREDITS) && at.equals(AccountType.LIABILITIES)) ||
                (mt.equals(MovementsType.DEBIT) && at.equals(AccountType.ASSETS))) {
            if (m.getAmount() > m.getAccount().getBalance())
                checked = false;
        }
        return checked;
    }

    /**
     * Richiama {@code getAccount} del Ledger.
     *
     * @return lista di Account
     */
    @Override
    public List<Account> getAccount() {
        return ledger.getAccount();
    }

    /**
     * Aggiunge un Account. Richiama {@code addAccount} del Ledger.
     *
     * @param id          id dell'Account da aggiungere
     * @param type        tipo dell'Account da aggiungere
     * @param name        nome dell'Account da aggiungere
     * @param description descrizione dell'Account da aggiungere
     * @param opening     balance iniziale dell'Account da aggiungere
     */
    @Override
    public void addAccount(int id, AccountType type, String name, String description, double opening) {
        ledger.addAccount(id, type, name, description, opening);
    }

    /**
     * Rimuove un Account. Richiama {@code removeAccount} del Ledger.
     *
     * @param account Account da rimuovere
     */
    @Override
    public void removeAccount(Account account) {
        ledger.removeAccount(account);
    }

    /**
     * Aggiunta di una Transaction. Richiama {@code addTransaction} del Ledger.
     *
     * @param t Transaction da aggiungere
     * @return Transaction aggiunta
     */
    @Override
    public Transaction addTransaction(Transaction t) {
        return ledger.addTransaction(t);
    }

    /**
     * Richiama {@code getTransactions} del Ledger.
     *
     * @return lista di Transaction
     */
    @Override
    public List<Transaction> getTransactions() {
        return ledger.getTransactions();
    }

    /**
     * Ritorna le Transaction con un predicato. Richiama {@code getTransactions} del Ledger.
     *
     * @param p predicato
     * @return lista di Transaction
     */
    @Override
    public List<Transaction> getTransactions(Predicate<Transaction> p) {
        return ledger.getTransactions(p);
    }

    /**
     * Rimuove una Transaction. Richiama {@code removeTransaction} del Ledger.
     *
     * @param transaction Transaction da rimuovere
     */
    @Override
    public void removeTransaction(Transaction transaction) {
        ledger.removeTransaction(transaction);
    }

    /**
     * Richiama {@code getTags} del Ledger.
     *
     * @return lista di Tag
     */
    @Override
    public List<Tag> getTags() {
        return ledger.getTags();
    }

    /**
     * Aggiunge un Tag. Richiama {@code addTag} del Ledger.
     *
     * @param id          id del Tag da aggiungere
     * @param name        nome del Tag da aggiungere
     * @param description descrizione del Tag da aggiungere
     */
    @Override
    public void addTag(int id, String name, String description) {
        ledger.addTag(id, name, description);
    }

    /**
     * Richiama {@code removeTag} del Ledger.
     *
     * @param tag Tag da rimuovere
     */
    @Override
    public void removeTag(Tag tag) {
        ledger.removeTag(tag);
    }


    /**
     * Richiama un oggetto per salvare i vari oggetti in file diversi
     *
     * @param path il path dove salvare i file
     * @throws IOException eccezione del path
     */
    @Override
    public void saveAsTxt(String path) throws IOException {
        SaverTxt saverTxt = new SaverTxt(path, this);
        saverTxt.saveAll();
    }


    /**
     * Importa dai file e ricrea gli oggetti.
     *
     * @param path path dei file da recuperare
     * @throws IOException    eccezione del path
     * @throws ParseException eccezione del parse
     */
    @Override
    public void importAsTxt(String path) throws IOException, ParseException {
        ImporterTxt importerTxt = new ImporterTxt(path, this);
        importerTxt.importAll();
    }


}

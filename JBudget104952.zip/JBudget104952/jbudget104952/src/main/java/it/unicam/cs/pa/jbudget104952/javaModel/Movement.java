package it.unicam.cs.pa.jbudget104952.javaModel;

import java.util.GregorianCalendar;
import java.util.List;

/**
 * I {@link Movement} sono movimenti che fanno parte di una transazione e
 * modificano il {@code balance} di un conto.
 * 
 * @author Greta Sorritelli
 *
 */
public interface Movement {

	int getID();

	String getDescription();

	MovementsType getType();

	double getAmount();

	Transaction getTransactions();

	GregorianCalendar getDate();

	List<Tag> getTag();

	Account getAccount();

	void addTag(Tag tag);

	void removeTag(Tag tag);

	void setTransaction(Transaction transaction);

}

package it.unicam.cs.pa.jbudget104952.javaPersistence;

import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import java.io.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * Classe per l'importazione da file txt
 *
 * @author Greta Sorritelli
 */
public class ImporterTxt implements Importer {

    private final SimpleLedgerController controller;

    private final String accountsPath;

    private final String transactionsPath;

    private final String movementsPath;

    private final String tagsPath;

    /**
     * Imposta il path per ogni file da cui importare
     *
     * @param directory directory della cartella in cui si trovano i file
     * @param controller il controller del ledger
     */
    public ImporterTxt(String directory, SimpleLedgerController controller) {
        this.controller = controller;
        accountsPath = directory + File.separator + "Accounts.txt";
        transactionsPath = directory + File.separator + "Transactions.txt";
        movementsPath = directory + File.separator + "Movements.txt";
        tagsPath = directory + File.separator + "Tags.txt";
    }

    /**
     * Si occupa di importare tutti gli oggetti.
     * @throws IOException eccezione del path
     * @throws ParseException eccezione del parse
     */
    @Override
    public void importAll() throws IOException, ParseException {
        List<String> accounts = importAccount();
        List<String> transactions = importTransaction();
        List<String> movements = importMovement();
        List<String> tags = importTag();
        accounts.forEach(this::loadAccountFromFile);
        tags.forEach(this::loadTagFromFile);
        for (String transaction : transactions) {
            loadTransactionFromFile(transaction);
        }
        movements.forEach(this::loadMovementFromFile);
    }

    /**
     * Salvataggio degli Account in una lista
     *
     * @return lista di stringhe relative agli account
     * @throws IOException per il path del file
     */
    public List<String> importAccount() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(accountsPath));
        List<String> accounts = new ArrayList<>();
        while (reader.ready())
            accounts.add(reader.readLine());
        return accounts;
    }

    /**
     * Salvataggio delle Transaction in una lista
     *
     * @return lista di stringhe relative alle transazioni
     * @throws IOException per il path del file
     */
    public List<String> importTransaction() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(transactionsPath));
        List<String> transactions = new ArrayList<>();
        while (reader.ready())
            transactions.add(reader.readLine());
        return transactions;
    }

    /**
     * Salvataggio dei Movement in una lista
     *
     * @return lista di stringhe relative ai movimenti
     * @throws IOException per il path del file
     */
    public List<String> importMovement() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(movementsPath));
        List<String> movements = new ArrayList<>();
        while (reader.ready())
            movements.add(reader.readLine());
        return movements;
    }

    /**
     * Salvataggio dei Tag in una lista
     *
     * @return lista di stringhe relative ai tag
     * @throws IOException per il path del file
     */
    public List<String> importTag() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader(tagsPath));
        List<String> tags = new ArrayList<>();
        while (reader.ready())
            tags.add(reader.readLine());
        return tags;
    }


    /**
     * Crea un oggetto Movement con i parametri dal file
     *
     * @param s stringa di un oggetto Movement
     */
    private void loadMovementFromFile(String s) {
        String[] movement = s.split(";");
        for (Transaction t : controller.getTransactions()) {
            if (t.getID() == Integer.parseInt(movement[5])) {
                if (getAccountMovement(movement[3]) != null) {
                    Movement m = new SimpleMovement(Integer.parseInt(movement[0]), movement[1], movementType(movement[2]), getAccountMovement(movement[3]), Double.parseDouble(movement[4]));
                    t.addMovement(m);
                    getAccountMovement(movement[3]).getMovements().add(m);
                    getAccountMovement(movement[3]).refreshBalance(m);
                    if (movement.length == 7)
                        m.getTag().addAll(reverseListToTags(movement[6]));
                }
            }
        }
    }

    /**
     * Crea un oggetto Tag con i parametri dal file
     *
     * @param s stringa di un oggetto Tag
     */
    private void loadTagFromFile(String s) {
        String[] tag = s.split(";");
        String desc = null;
        if (s.length() == 3) {
            desc = tag[2];
        }
        controller.addTag(Integer.parseInt(tag[0]), tag[1], desc);
    }

    /**
     * Crea un oggetto Transaction con i parametri dal file
     *
     * @param s stringa di un oggetto Transaction
     */
    private void loadTransactionFromFile(String s) throws ParseException {
        String[] transaction = s.split(";");
        Transaction t = new SimpleTransaction(Integer.parseInt(transaction[0]), convertDate(transaction[1]));
        controller.addTransaction(t);
        if (transaction.length == 3)
            t.getTags().addAll(reverseListToTags(transaction[2]));
    }

    /**
     * Crea un oggetto Account con i parametri dal file
     *
     * @param s stringa di un oggetto Account
     */
    private void loadAccountFromFile(String s) {
        String[] account = s.split(";");
        controller.addAccount(Integer.parseInt(account[0]), accountType(account[1]), account[2], account[3], Double.parseDouble(account[4]));
    }


    /**
     * Converte una stringa in una data GregorianCalendar
     *
     * @param s stringa della data
     * @return data in GregorianCalendar
     * @throws ParseException eccezione del parse
     */
    private GregorianCalendar convertDate(String s) throws ParseException {
        DateFormat df = new SimpleDateFormat("dd-MMM-yyyy");
        Date date = df.parse(s);
        GregorianCalendar cal = new GregorianCalendar();
        cal.setTime(date);
        return cal;
    }

    /**
     * Restituisce una lista di Tag da una lista di nomi di tag
     *
     * @param s stringa della lista
     * @return lista di tag
     */
    private List<Tag> reverseListToTags(String s) {
        List<Tag> tags = new ArrayList<>();
        String[] tag = s.split("[\\[\\]{}]");
        for (String str : tag) {
            for (Tag t : controller.getTags()) {
                if (t.getName().equals(str))
                    tags.add(t);
            }
        }
        return tags;
    }

    private MovementsType movementType(String s) {
        return MovementsType.valueOf(s);
    }

    private AccountType accountType(String s) {
        return AccountType.valueOf(s);
    }

    private Account getAccountMovement(String s) {
        Account acc = null;
        for (Account a : controller.getAccount()) {
            if (a.getID() == Integer.parseInt(s))
                acc = a;
        }
        return acc;
    }

}

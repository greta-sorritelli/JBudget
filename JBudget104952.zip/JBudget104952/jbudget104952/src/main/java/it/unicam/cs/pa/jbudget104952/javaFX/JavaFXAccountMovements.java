package it.unicam.cs.pa.jbudget104952.javaFX;

import it.unicam.cs.pa.jbudget104952.javaController.SimpleLedgerController;
import it.unicam.cs.pa.jbudget104952.javaModel.*;
import javafx.beans.property.SimpleObjectProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.*;
import java.util.function.Predicate;

public class JavaFXAccountMovements implements JavaFXFilter {

    private final SimpleLedgerController controller;

    /**
     * Account di cui si vogliono visualizzare i movimenti
     */
    private Account account;

    public JavaFXAccountMovements(SimpleLedgerController controller) {
        this.controller = controller;
    }

    public void setAccount(Account account) {
        this.account = account;
    }

    @FXML
    Label accountText = new Label();
    @FXML
    TableView<Movement> movementTableView = new TableView<>();
    @FXML
    TableColumn<Movement, Integer> movementID = new TableColumn<>();
    @FXML
    TableColumn<Movement, Date> movementDate = new TableColumn<>();
    @FXML
    TableColumn<Movement, MovementsType> movementType = new TableColumn<>();
    @FXML
    TableColumn<Movement, String> movementDescription = new TableColumn<>();
    @FXML
    TableColumn<Movement, Integer> movementTransaction = new TableColumn<>();
    @FXML
    TableColumn<Movement, Double> movementAmount = new TableColumn<>();
    @FXML
    TableColumn<Movement, List<Tag>> movementTags = new TableColumn<>();


    @FXML
    public void initialize() {
        accountText.setText(account.toString());
        movementRefresh();
        fillListTransactions();
        fillListTags();
        initTag();
        initTransaction();
        initType();
    }

    /**
     * Aggiorna i dati della tabella relativa ai Movement dell'Account.
     */
    @FXML
    public void movementRefresh() {
        setMovementCellValueFactory();
        movementTableView.getItems().clear();
        for (Movement movement : account.getMovements())
            movementTableView.getItems().add(movement);
    }

    /**
     * Riempie la tabella con i dati dei Movement.
     */
    private void setMovementCellValueFactory() {
        movementID.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getID()));
        movementType.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getType()));
        movementDate.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getDate().getTime()));
        movementDescription.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getDescription()));
        movementTransaction.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getTransactions().getID()));
        movementAmount.setCellValueFactory(movement -> new SimpleObjectProperty<>(movement.getValue().getAmount()));
        movementTags.setCellValueFactory(movement -> new SimpleObjectProperty<>((movement.getValue().getTag())));
    }


    @FXML
    TextField idFilter = new TextField();
    @FXML
    ChoiceBox<MovementsType> typeFilter = new ChoiceBox<>();
    final ObservableList<MovementsType> types = FXCollections.observableArrayList(MovementsType.CREDITS, MovementsType.DEBIT);
    @FXML
    ChoiceBox<Integer> transactionFilter = new ChoiceBox<>();
    final ObservableList<Integer> transactions = FXCollections.observableArrayList();
    @FXML
    ChoiceBox<Tag> tagFilter = new ChoiceBox<>();
    final ObservableList<Tag> tags = FXCollections.observableArrayList();
    @FXML
    DatePicker dateFilter = new DatePicker();


    private void fillListTransactions() {
        for (Transaction t : controller.getTransactions()) {
            if (!transactions.contains(t.getID()))
                transactions.add(t.getID());
        }
    }

    private void fillListTags() {
        for(Tag t : controller.getTags()) {
            if(!tags.contains(t))
                tags.add(t);
        }
    }

    @FXML
    public void initType() {
        typeFilter.setItems(types);
    }

    @FXML
    public void initTransaction() {
        transactionFilter.setItems(transactions);
    }

    @FXML
    public void initTag() {
        tagFilter.setItems(tags);
    }


    /**
     * Filtra i movimenti con i vari parametri assegnati come predicati
     */
    @FXML
    @Override
    public void filter() {
        movementTableView.getItems().clear();
        List<Predicate<Movement>> finalPredicate = new ArrayList<>();
        controlID(finalPredicate);
        controlDate(finalPredicate);
        controlTransaction(finalPredicate);
        controlType(finalPredicate);
        controlTag(finalPredicate);
        reduce(finalPredicate);
    }

    /**
     * Crea un predicato per l'ID se è inserito come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlID(List<Predicate<Movement>> finalPredicate) {
        if (!idFilter.getText().equals("")) {
            Predicate<Movement> idPredicate;
            try {
                if (Integer.parseInt(idFilter.getText()) > 0) {
                    idPredicate = (movement -> movement.getID() == Integer.parseInt(idFilter.getText()));
                    finalPredicate.add(idPredicate);
                }
            } catch (Exception e) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Invalid ID.");
                alert.showAndWait();
                e.printStackTrace();
            }
        }
    }

    /**
     * Crea un predicato per la data se è inserita come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlDate(List<Predicate<Movement>> finalPredicate) {
        LocalDate date;
        ZonedDateTime zonedDateTime;
        if (dateFilter.getValue() != null) {
            date = dateFilter.getValue();
            zonedDateTime = date.atStartOfDay(ZoneId.systemDefault());
            Predicate<Movement> datePredicate;
            datePredicate = (movement -> movement.getDate().equals(GregorianCalendar.from(zonedDateTime)));
            finalPredicate.add(datePredicate);

        }
    }

    /**
     * Crea un predicato per la Transaction se è inserita come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlTransaction(List<Predicate<Movement>> finalPredicate) {
        Transaction transaction;
        if (transactionFilter.getValue() != null) {
            for (Transaction t : controller.getTransactions()) {
                if (t.getID() == transactionFilter.getValue()) {
                    transaction = t;
                    Predicate<Movement> transPredicate;
                    Transaction finalTransaction = transaction;
                    transPredicate = (movement -> movement.getTransactions().equals(finalTransaction));
                    finalPredicate.add(transPredicate);

                }
            }
        }
    }

    /**
     * Crea un predicato per il type se è inserito come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlType(List<Predicate<Movement>> finalPredicate) {
        if (typeFilter.getValue() != null) {
            Predicate<Movement> typePredicate;
            typePredicate = (movement -> movement.getType().equals(typeFilter.getValue()));
            finalPredicate.add(typePredicate);
        }
    }

    /**
     * Crea un predicato per il Tag se è inserito come parametro
     * @param finalPredicate lista di predicati a cui aggiungere il predicato
     */
    private void controlTag(List<Predicate<Movement>> finalPredicate) {
        if (tagFilter.getValue() != null) {
            Predicate<Movement> tagPredicate;
            tagPredicate = (movement -> movement.getTag().contains(tagFilter.getValue()));
            finalPredicate.add(tagPredicate);
        }
    }

    /**
     * Riduce la lista di predicati ad un solo predicato.
     * I predicati sono concatenati con gli and logici, tutti i predicati devono essere soddisfatti.
     * @param list lista di parametri da ridurre
     */
    public void reduce(List<Predicate<Movement>> list) {
        Predicate<Movement> predicate = list.stream()
                .reduce(x -> true, Predicate::and);
        showMovements(predicate);
    }

    private void showMovements(Predicate<Movement> predicate) {
        movementTableView.getItems().clear();
        for (Movement movement : account.getMovements(predicate))
            movementTableView.getItems().add(movement);
    }

    /**
     * Resetta i campi dei parametri da inserire e ritorna la lista iniziale di tutti i movimenti dell'Account
     */
    @FXML
    @Override
    public void reset() {
        idFilter.clear();
        dateFilter.getEditor().clear();
        transactionFilter.getSelectionModel().clearSelection();
        tagFilter.getSelectionModel().clearSelection();
        typeFilter.getSelectionModel().clearSelection();
        movementRefresh();
    }

}
